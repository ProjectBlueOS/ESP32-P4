# Email Test Application
SYSTEM.APPNAME "Email Sender"

LET email_sent = 0
LET net_connected = 0
LET btn_pressed = 0
LET email_status = ""

:onUpdate
  LET net_connected = Network.IsConnected
RETURN

:onDraw
  Graphics.FillRect 0, 0, 396, 300, BLACK
  Graphics.DrawString 10, 10, "Email Sender Pro", CYAN
  Graphics.DrawString 10, 40, "Press 'E' or click button to send", WHITE
  
  IF net_connected = 0 THEN
    Graphics.DrawString 10, 80, "WiFi: Disconnected", RED
  ELSE
  Network.GetIP
  LET ss = "WiFi: Connected:" + net_ip
    Graphics.DrawString 10, 80, ss, GREEN
  ENDIF

  # Draw button (x=10, y=110, w=160, h=30)
  Graphics.DrawButton 10, 110, 160, 30, "Send Test Email", btn_pressed
  
 
  
  # Status feedback
  IF email_sent = 1 THEN
    Graphics.DrawString 10, 160, "Status: " + email_status, GOLD
  ENDIF
RETURN

:onMouseEvent
  IF event_type = "Down" THEN
    # Check button bounds using nested IFs (AND not supported)
    IF event_x >= 10 THEN
      IF event_x <= 170 THEN
        IF event_y >= 110 THEN
          IF event_y <= 140 THEN
            LET btn_pressed = 1
          ENDIF
        ENDIF
      ENDIF
    ENDIF
  ENDIF

  IF event_type = "Up" THEN
    IF btn_pressed = 1 THEN
      LET btn_pressed = 0
      IF event_x >= 10 THEN
        IF event_x <= 170 THEN
          IF event_y >= 110 THEN
            IF event_y <= 140 THEN
              IF net_connected = 1 THEN
                LET email_sent = 1
                LET email_status = "Sending..."
Network.SendEmail "devante.julian@gmail.com", "Alert", "Custom server: Email Message from BlueScript", "smtp.google.com", 587, "hkkgyyilfawdgzbi"

                LET email_status = "Success! (Sent)"
              ELSE
                LET email_sent = 1
                LET email_status = "Error: No WiFi"
              ENDIF
            ENDIF
          ENDIF
        ENDIF
      ENDIF
    ENDIF
  ENDIF
RETURN

:onKeyboardEvent
  IF event_type = "KeyDown" THEN
    IF event_value = "e" THEN
      IF net_connected = 1 THEN
        LET email_sent = 1
        LET email_status = "Sending (Key)..."
        Network.SendEmail "devante.julian@gmail.com", "BlueScript Test", "Sent via Keyboard!"
        LET email_status = "Success!"
      ELSE
        LET email_sent = 1
        LET email_status = "Error: No WiFi"
      ENDIF
    ENDIF
  ENDIF
RETURN
