# BounceBall.bb - Simple Bouncing Ball
SYSTEM.APPNAME "BounceBall"

# Ball position and velocity
LET x = 200.0
LET y = 150.0
LET vx = 150.0
LET vy = 120.0
LET radius = 16.0

# Box boundaries
LET boxX = 50.0
LET boxY = 50.0
LET boxW = 300.0
LET boxH = 200.0

:onUpdate
  # Update position
  LET x = (x + (vx * delta_time))
  LET y = (y + (vy * delta_time))

  # Bounce off walls
  IF x < (boxX + radius) THEN
    LET x = (boxX + radius)
    LET vx = (vx * -1.0)
  ENDIF
  IF x > (boxX + boxW - radius) THEN
    LET x = (boxX + boxW - radius)
    LET vx = (vx * -1.0)
  ENDIF
  IF y < (boxY + radius) THEN
    LET y = (boxY + radius)
    LET vy = (vy * -1.0)
  ENDIF
  IF y > (boxY + boxH - radius) THEN
    LET y = (boxY + boxH - radius)
    LET vy = (vy * -1.0)
  ENDIF
RETURN

:onDraw
  # Clear screen
  Graphics.FillRect 0, 0, 400, 300, BLACK

  # Draw box
  Graphics.DrawRect boxX, boxY, boxW, boxH, WHITE

  # Glowing ball: layered halo around a bright core
  Graphics.FillCircle x, y, (radius + 14), 0x3000
  Graphics.FillCircle x, y, (radius + 8), 0xA000
  Graphics.FillCircle x, y, (radius + 3), 0xF000
  Graphics.FillCircle x, y, radius, RED
  Graphics.FillCircle (x - 5), (y - 6), (radius - 8), WHITE

  # Title
  Graphics.DrawString 160, 20, "BOUNCING BALL", WHITE
RETURN
