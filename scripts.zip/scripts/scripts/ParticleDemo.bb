# ParticleDemo.bb - Orbital Nexus
SYSTEM.APPNAME "Orbital Nexus"

LET t = 0.0
LET spx = 198
LET spy = 135

:onUpdate
  # Advance angles
  LET t = ((t + (30.0 * delta_time)) % 360.0)
  
  # Center positions - centered in content area above status bar
  LET cx = 198
  LET cy = 135

  # Orbit calculations using parentheses for clarity
  Math.Sin t
  LET px0 = (cx + result * 80)
  Math.Cos t
  LET py0 = (cy + result * 60)

  Math.Sin (t + 90)
  LET px1 = (cx + result * 80)
  Math.Cos (t + 90)
  LET py1 = (cy + result * 60)

  Math.Sin (t + 180)
  LET px2 = (cx + result * 80)
  Math.Cos (t + 180)
  LET py2 = (cy + result * 60)

  Math.Sin (t + 270)
  LET px3 = (cx + result * 80)
  Math.Cos (t + 270)
  LET py3 = (cy + result * 60)

  # Inner orbits
  Math.Sin (t * 2)
  LET px4 = (cx + result * 35)
  Math.Cos (t * 2)
  LET py4 = (cy + result * 35)

  Math.Sin (360 - t * 2)
  LET px5 = (cx + result * 35)
  Math.Cos (360 - t * 2)
  LET py5 = (cy + result * 35)

  # Random spark
  Math.Random 20, 376
  LET spx = result
  Math.Random 10, 260
  LET spy = result
RETURN

:onDraw
  Graphics.FillRect 0, 0, 396, 300, BLACK

  # Background decoration
  Graphics.DrawCircle 198, 135, 80, NAVY
  Graphics.DrawCircle 198, 135, 35, NAVY
  Graphics.DrawCircle 198, 135, 3, DARKGRAY

  # Connection web
  Graphics.DrawLine px0, py0, px1, py1, NAVY
  Graphics.DrawLine px1, py1, px2, py2, NAVY
  Graphics.DrawLine px2, py2, px3, py3, NAVY
  Graphics.DrawLine px3, py3, px0, py0, NAVY
  Graphics.DrawLine px0, py0, px2, py2, TEAL
  Graphics.DrawLine px1, py1, px3, py3, TEAL

  Graphics.DrawLine px4, py4, px5, py5, PURPLE
  Graphics.DrawLine px4, py4, 198, 135, DARKGRAY
  Graphics.DrawLine px5, py5, 198, 135, DARKGRAY

  Graphics.DrawTriangle px0, py0, px1, py1, px4, py4, TEAL
  Graphics.DrawTriangle px2, py2, px3, py3, px5, py5, PURPLE

  # Particles with glow halos
  Graphics.FillCircle px0, py0, 12, NAVY
  Graphics.FillCircle px0, py0, 5, CYAN
  Graphics.FillCircle px1, py1, 12, MAROON
  Graphics.FillCircle px1, py1, 5, RED
  Graphics.FillCircle px2, py2, 12, NAVY
  Graphics.FillCircle px2, py2, 5, CYAN
  Graphics.FillCircle px3, py3, 12, MAROON
  Graphics.FillCircle px3, py3, 5, RED

  Graphics.FillCircle px4, py4, 8, PURPLE
  Graphics.FillCircle px4, py4, 4, MAGENTA
  Graphics.FillCircle px5, py5, 8, TEAL
  Graphics.FillCircle px5, py5, 4, GREEN

  # Center pulse
  Graphics.FillCircle 198, 135, ((t % 6.0) + 3), NAVY
  Graphics.FillCircle 198, 135, 3, WHITE

  # Sparks
  Graphics.FillCircle spx, spy, 1, WHITE

  # Collision flash
  Collision.Circle px0, py0, 10, px4, py4, 10
  IF collision_hit = 1 THEN
    Graphics.FillCircle px0, py0, 20, YELLOW
  ENDIF
  Collision.Circle px1, py1, 10, px5, py5, 10
  IF collision_hit = 1 THEN
    Graphics.FillCircle px1, py1, 20, ORANGE
  ENDIF

  # UI
  Graphics.DrawProportional 70, 5, "ORBITAL NEXUS", CYAN, 0, 0.6
  Graphics.FillRect 0, 272, 396, 28, NAVY
  Graphics.DrawLine 0, 272, 396, 272, CYAN
  Graphics.DrawProportional 10, 272, "ORBITAL NEXUS | ACTIVE", SILVER, 0, 0.6

  SYSTEM.TOP
  Graphics.DrawString 8, 280, "FillCircle+Collision // NATIVE", CYAN
  Graphics.DrawString 270, 280, ("HEAP:" + mem_free), DARKGRAY
RETURN
